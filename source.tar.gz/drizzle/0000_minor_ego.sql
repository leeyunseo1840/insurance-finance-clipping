CREATE TABLE `editions` (
	`date` text PRIMARY KEY NOT NULL,
	`updated_at` text NOT NULL,
	`payload` text NOT NULL
);
