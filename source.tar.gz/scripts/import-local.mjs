import {readFileSync,mkdirSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {validateEdition} from '../lib/validation.mjs';
const d=JSON.parse(readFileSync('work/edition.json','utf8'));
if(!validateEdition(d))throw Error('Invalid edition');
mkdirSync('work/data',{recursive:true});
const db=new DatabaseSync('work/data/clipping.sqlite');
db.exec('CREATE TABLE IF NOT EXISTS editions (date TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL)');
db.prepare('INSERT INTO editions (date,updated_at,payload) VALUES (?,?,?) ON CONFLICT(date) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload WHERE excluded.updated_at>=editions.updated_at').run(d.date,d.updatedAt,JSON.stringify(d));
console.log(JSON.stringify({stored:d.items.length,date:d.date}));
db.close();

