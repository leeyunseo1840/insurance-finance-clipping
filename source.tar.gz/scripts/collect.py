"""Official RSS + optional Naver Search. Python 3.11+, standard library only."""
import concurrent.futures, datetime as dt, email.utils, hashlib, html, json, os, re, sys, time, urllib.parse, urllib.request, xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
UTC=dt.timezone.utc
KST=dt.timezone(dt.timedelta(hours=9))
CATEGORIES=['보험상품','제도·정책','GA·설계사','소비자·보상','보험사','인슈어테크/헬스케어']
DOMAINS={'yna.co.kr':('연합뉴스','major'),'newsis.com':('뉴시스','major'),'news1.kr':('뉴스1','major'),'hankyung.com':('한국경제','major'),'mk.co.kr':('매일경제','major'),'sedaily.com':('서울경제','major'),'mt.co.kr':('머니투데이','major'),'edaily.co.kr':('이데일리','major'),'chosun.com':('조선일보','major'),'donga.com':('동아일보','major'),'joongang.co.kr':('중앙일보','major'),'hani.co.kr':('한겨레','major'),'khan.co.kr':('경향신문','major'),'kbs.co.kr':('KBS','major'),'imbc.com':('MBC','major'),'sbs.co.kr':('SBS','major'),'mbn.co.kr':('MBN','major'),'insjournal.co.kr':('보험저널','specialist'),'insnews.co.kr':('한국보험신문','specialist'),'fins.co.kr':('보험매일','specialist')}
KEYWORDS=['금리','물가','대출','연금','세금','전세','금융사기','예금자보호','실손보험','자동차보험','암보험','건강보험','종신보험','보험료','보험금','보험사기','보험설계사','법인보험대리점','GA','금융감독원','금융위원회','해약환급금','인슈어테크','헬스케어','간병보험','연금보험','판매수수료','보장','청구']
def clean(s): return re.sub(r'\s+',' ',html.unescape(re.sub(r'<[^>]+>',' ',s or ''))).strip()
def source_for(url):
    host=(urllib.parse.urlsplit(url).hostname or '').lower()
    return next((v for k,v in DOMAINS.items() if host==k or host.endswith('.'+k)),None)
def safe_url(url):
    try:
        p=urllib.parse.urlsplit(url)
        return p.scheme in ('https','http') and bool(p.hostname) and not p.username and not p.password
    except ValueError:return False

def canonical(url):
    p=urllib.parse.urlsplit(url)
    q=urllib.parse.urlencode([(k,v) for k,v in urllib.parse.parse_qsl(p.query) if not k.lower().startswith('utm_') and k.lower() not in ('fbclid','gclid')])
    return urllib.parse.urlunsplit((p.scheme,p.netloc.lower(),p.path,q,''))
def fetch(url,headers=None):
    for attempt in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'InsuranceDailyBrief/1.0 (RSS reader)',**(headers or {})})
            with urllib.request.urlopen(req,timeout=20) as r:
                data=r.read(3_000_001)
                if len(data)>3_000_000:raise ValueError('Feed exceeds size limit')
                return data
        except Exception:
            if attempt==2:raise
            time.sleep(attempt+1)
def parse_date(s):
    try:d=email.utils.parsedate_to_datetime(s)
    except Exception:
        try:d=dt.datetime.fromisoformat(s.replace('Z','+00:00'))
        except Exception:return None
    return d.astimezone(UTC) if d.tzinfo else None

def parse_feed(data,config):
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():raise ValueError('Unsafe XML')
    root=ET.fromstring(data);out=[]
    for node in root.iter():
        if node.tag.split('}')[-1] not in ('item','entry'):continue
        fields={c.tag.split('}')[-1]:c for c in node}
        def value(*names):
            for name in names:
                if name in fields:return ''.join(fields[name].itertext())
            return ''
        link=value('link')
        if not link and 'link' in fields:link=fields['link'].attrib.get('href','')
        title=clean(value('title'));date=parse_date(value('pubDate','published','updated','date'))
        if not date or not safe_url(link):continue
        out.append({'title':title,'description':clean(value('description','summary'))[:1500],'url':canonical(link),'publishedAt':date.isoformat(),'source':config['name'],'tier':config['tier'],'headline':bool(config.get('headline'))})
    return out

def naver_news():
    client=os.getenv('NAVER_CLIENT_ID');secret=os.getenv('NAVER_CLIENT_SECRET')
    if not client and not secret:return []
    if not client or not secret:raise ValueError('Both Naver credentials required')
    results=[]
    for query in ('보험','실손보험','보험설계사','보험금','인슈어테크','금리 물가','연금 세금','대출 전세','금융사기'):
        for start in (1,101):
            url='https://openapi.naver.com/v1/search/news.json?'+urllib.parse.urlencode({'query':query,'display':100,'start':start,'sort':'date'})
            payload=json.loads(fetch(url,{'X-Naver-Client-Id':client,'X-Naver-Client-Secret':secret}))
            for item in payload.get('items',[]):
                link=item.get('originallink');src=source_for(link or '');date=parse_date(item.get('pubDate',''))
                if not src or not date or not safe_url(link):continue
                results.append({'title':clean(item['title']),'description':clean(item.get('description','')),'url':canonical(link),'publishedAt':date.isoformat(),'source':src[0],'tier':src[1],'headline':False})
            if len(payload.get('items',[]))<100:break
    return results

ECONOMY=r'기준금리|대출|주담대|가계부채|예금|적금|물가|소비자물가|환율|소득세|상속세|증여세|연말정산|세액공제|국민연금|퇴직연금|기초연금|전세|월세|주거|청약|보이스피싱|금융사기|예금자보호|가계소득|생활비|전기요금|가스요금'
def relevant(text):
    return bool(re.search(r'보험|실손|인슈어테크|법인보험대리점|'+ECONOMY,text))
def category(title):
    if not re.search(r'보험|실손|설계사|인슈어테크',title) and re.search(ECONOMY,title):return '경제·금융'
    rules=[('제도·정책',r'건보료|건강보험료|건강보험정책'),('GA·설계사',r'설계사|대리점|모집인|수수료|\bGA\b'),('제도·정책',r'금융위|금감원|금융감독원|법안|개정|제도|규제|정책|의무화'),('소비자·보상',r'청구|보험금|보상|분쟁|소비자|보험사기|지급|피해'),('인슈어테크/헬스케어',r'인슈어테크|헬스케어|디지털|AI|인공지능'),('보험상품',r'보험료|상품|실손|암보험|종신|간병|보장|자동차보험')]
    return next((c for c,p in rules if re.search(p,title,re.I)),'보험사')

def grams(title):
    title=re.sub(r'\[[^]]*\]|\([^)]*\)','',title)
    s=re.sub(r'[^가-힣a-z0-9]','',title.lower())
    return {s[i:i+3] for i in range(len(s)-2)}

def similar(a,b):
    if a['url']==b['url']:return True
    if abs((parse_date(a['publishedAt'])-parse_date(b['publishedAt'])).total_seconds())>48*3600:return False
    x,y=grams(a['title']),grams(b['title'])
    if not x or not y:return False
    # Conservative complete-link groups avoid joining distinct stories through a bridge.
    return len(x&y)/len(x|y)>=0.44 or len(x&y)/min(len(x),len(y))>=0.74

def cluster(items):
    unique={}
    for a in items:
        if a['url'] in unique:unique[a['url']]['headline'] |= a['headline']
        else:unique[a['url']]=a.copy()
    groups=[]
    for a in sorted(unique.values(),key=lambda a:a['publishedAt'],reverse=True):
        target=next((g for g in groups if all(similar(a,b) for b in g)),None)
        if target is None:groups.append([a])
        else:target.append(a)
    return groups
CHECKS={'보험상품':'가입 대상과 보장 범위, 보험료 변화가 고객에게 미치는 영향을 확인하세요.','제도·정책':'확정된 조치인지 검토 단계인지 구분하고 시행일·적용 대상을 확인하세요.','GA·설계사':'모집 현장의 설명 의무와 판매·수수료 조건에 달라지는 점을 확인하세요.','소비자·보상':'청구 요건과 보상 제외 사항을 확인해 고객이 오해하기 쉬운 지점을 짚어보세요.','보험사':'기업 발표와 소비자에게 실제로 적용되는 변화를 구분해 확인하세요.','인슈어테크/헬스케어':'서비스 이용 대상과 비용, 개인정보 동의 조건을 확인하세요.'}
def edition_from(items,now,warnings):
    cutoff=now-dt.timedelta(hours=48)
    selected=[a for a in items if cutoff<=parse_date(a['publishedAt'])<=now+dt.timedelta(minutes=10) and relevant(a['title']+' '+a['description'])]
    out=[]
    for group in cluster(selected):
        rep=max(group,key=lambda a:(a['tier']=='major',a['headline'],a['publishedAt']))
        cat=category(rep['title']);major=len({a['source'] for a in group if a['tier']=='major'});headline=any(a['headline'] for a in group)
        major_sources=len({a['source'] for a in group if a['tier']=='major'})
        score=2.1+(0.7 if major else 0)+min(max(major-1,0)*0.35,1.05)+(0.4 if headline else 0)+(0.2 if major_sources>=2 else 0)+(0.55 if cat in ('소비자·보상','제도·정책') else 0.2)
        if re.search(r'이벤트|캠페인|수상|기부|후원|브랜드대상',rep['title']):score-=0.7
        reasons=[f'주요 매체 {major}곳 보도' if major else '보험 전문매체 보완 기사',f'{cat} 관련성']
        if major_sources>=2: reasons.append('복수 주요 언론 동시 보도')
        if headline:reasons.append('공식 헤드라인 RSS 노출 확인 (지면 1면 확인 아님)')
        desc=rep['description'];sentences=re.split(r'(?<=[.!?])(?!\d)\s*',desc)
        summary=[s[:180] for s in sentences if len(s)>12][:2]
        if not summary:summary=['공개 피드에 상세 설명이 제공되지 않았습니다.','기사 제목 외의 세부 내용은 원문에서 확인해 주세요.']
        elif len(summary)==1:summary.append('공개 피드의 핵심 내용을 발췌했습니다. 세부 조건은 원문을 확인해 주세요.')
        out.append({'id':hashlib.sha256(rep['url'].encode()).hexdigest()[:20],'title':rep['title'],'category':cat,'summary':summary,'summaryMode':'extractive','check':CHECKS.get(cat,'고객의 생활비·자산·노후에 달라지는 점과 적용 대상을 확인하세요.'),'score':round(max(1,min(5,score)),1),'source':rep['source'],'publishedAt':rep['publishedAt'],'url':rep['url'],'related':[{'source':a['source'],'title':a['title'],'url':a['url']} for a in group if a['url']!=rep['url']],'reasons':reasons})
    reviews=json.loads((ROOT/'config/reviews.json').read_text(encoding='utf-8'))
    for item in out:
        if item['url'] in reviews:item['review']=reviews[item['url']]
    out.sort(key=lambda a:(a['score'],a['publishedAt']),reverse=True)
    counts={k:sum(k.lower() in a['title'].lower() for a in out) for k in KEYWORDS}
    return {'date':now.astimezone(KST).date().isoformat(),'updatedAt':now.isoformat(),'items':out[:100],'keywords':[k for k in sorted(counts,key=counts.get,reverse=True) if counts[k]][:10],'warnings':warnings}

def main():
    feeds=json.loads((ROOT/'config/feeds.json').read_text(encoding='utf-8-sig'));items=[];warnings=[];success=0
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(lambda f:parse_feed(fetch(f['url']),f),f):f for f in feeds}
        for future,f in futures.items():
            try:items.extend(future.result());success+=1
            except Exception as e:warnings.append(f['name']+': '+type(e).__name__)
    try:
        news=naver_news();items.extend(news)
        if os.getenv('NAVER_CLIENT_ID'):success+=1
    except Exception as e:warnings.append('Naver: '+type(e).__name__)
    if not success:raise RuntimeError('All sources failed; existing edition preserved')
    payload=edition_from(items,dt.datetime.now(UTC),warnings)
    if not payload['items']:raise RuntimeError('No recent relevant articles; existing edition preserved')
    dest=Path(os.getenv('OUTPUT_FILE',str(ROOT/'work/edition.json')));dest.parent.mkdir(parents=True,exist_ok=True)
    tmp=dest.with_suffix('.tmp');tmp.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8');tmp.replace(dest)
    target=os.getenv('CLIPPING_IMPORT_URL');token=os.getenv('CLIPPING_IMPORT_TOKEN')
    if target:
        if not target.startswith('https://') or not token:raise ValueError('HTTPS import URL and token required')
        req=urllib.request.Request(target,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
        with urllib.request.urlopen(req,timeout=60) as r:
            if r.status!=200:raise RuntimeError('Import failed')
    print(json.dumps({'date':payload['date'],'issues':len(payload['items']),'successfulSources':success,'warnings':warnings},ensure_ascii=False))
if __name__=='__main__':main()


