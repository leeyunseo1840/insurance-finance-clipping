"""Build durable static editions. Previous files stay untouched if collection fails."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'work/edition.json').read_text(encoding='utf-8'))
items=d['items'];top=items[0] if items else None
# Free mode uses source excerpts; it never invents AI analysis or verified events.
if top:
 review=top.get('review')
 impact=review['interpretation'] if review else '보도 요약 · '+top['summary'][0]
 watch='다음 발표·시행 일정은 아직 확인되지 않았습니다.'
 if review and review.get('effectiveDate'):watch='적용 시점 · '+review['effectiveDate']
 d['morning']={'headline':top['title'],'impact':impact,'watch':watch,'url':top['url']}
out=root/'public/data';out.mkdir(parents=True,exist_ok=True)
existing=sorted([p.stem for p in out.glob('????-??-??.json')],reverse=True)
dates=sorted(set(existing+[d['date']]),reverse=True)[:366]
body=json.dumps({'edition':d,'dates':dates},ensure_ascii=False)
for name in (d['date'],'latest'):
 tmp=out/(name+'.tmp');tmp.write_text(body,encoding='utf-8');tmp.replace(out/(name+'.json'))
print(f'Published {len(items)} issues for {d["date"]}')
