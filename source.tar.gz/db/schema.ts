import {sqliteTable,text} from 'drizzle-orm/sqlite-core';
export const editions=sqliteTable('editions',{date:text('date').primaryKey(),updatedAt:text('updated_at').notNull(),payload:text('payload').notNull()});
