import {createServer} from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {authorized,validateEdition} from './lib/validation.mjs';
const data=resolve(process.env.DATA_DIR||'work/data');await mkdir(data,{recursive:true});
const db=new DatabaseSync(resolve(data,'clipping.sqlite'));db.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS editions (date TEXT PRIMARY KEY, updated_at TEXT NOT NULL, payload TEXT NOT NULL)');
const root=resolve('dist-render');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'};
createServer(async(req,res)=>{const send=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data))};try{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/healthz')return send(200,{ok:true});
 if(u.pathname==='/api/news'&&req.method==='GET'){const date=u.searchParams.get('date');if(date&&!/^\d{4}-\d{2}-\d{2}$/.test(date))return send(400,{error:'Invalid date'});const row=date?db.prepare('SELECT payload FROM editions WHERE date=?').get(date):db.prepare('SELECT payload FROM editions ORDER BY date DESC LIMIT 1').get();return send(200,{edition:row?JSON.parse(row.payload):null,dates:db.prepare('SELECT date FROM editions ORDER BY date DESC LIMIT 366').all().map(r=>r.date)})}
 if(u.pathname==='/api/import'&&req.method==='POST'){const r=new Request('http://localhost',{headers:{authorization:req.headers.authorization||''}});if(!await authorized(r,process.env.CLIPPING_IMPORT_TOKEN))return send(401,{error:'Unauthorized'});const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>1000000)return send(413,{error:'Too large'});chunks.push(chunk)}let d;try{d=JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{return send(400,{error:'Invalid JSON'})}if(!validateEdition(d))return send(400,{error:'Invalid edition'});db.prepare('INSERT INTO editions (date,updated_at,payload) VALUES (?,?,?) ON CONFLICT(date) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload WHERE excluded.updated_at>editions.updated_at').run(d.date,d.updatedAt,JSON.stringify(d));return send(200,{ok:true,date:d.date,issues:d.items.length})}
 if(u.pathname.startsWith('/api/'))return send(404,{error:'Not found'});if(!['GET','HEAD'].includes(req.method))return send(405,{error:'Method not allowed'});
 const path=resolve(root,'.'+decodeURIComponent(u.pathname==='/'?'/index.html':u.pathname));if(!path.startsWith(root+sep))return send(403,{error:'Forbidden'});const bytes=await readFile(path);res.writeHead(200,{'Content-Type':mime[extname(path)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','Content-Security-Policy':"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"});res.end(req.method==='HEAD'?undefined:bytes)
 }catch(e){send(e.code==='ENOENT'?404:500,{error:e.code==='ENOENT'?'Not found':'Server error'})}}).listen(Number(process.env.PORT||3000),'0.0.0.0');
