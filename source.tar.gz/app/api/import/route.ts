import {env} from 'cloudflare:workers';
import {authorized,validateEdition} from '@/lib/validation.mjs';
export async function POST(request:Request){
 const bindings=env as unknown as {DB:D1Database;CLIPPING_IMPORT_TOKEN?:string};
 if(!await authorized(request,bindings.CLIPPING_IMPORT_TOKEN))return Response.json({error:'Unauthorized'},{status:401});
 if(Number(request.headers.get('content-length')||0)>1000000)return Response.json({error:'Too large'},{status:413});
 try{const body=await request.text();if(body.length>1000000)return Response.json({error:'Too large'},{status:413});const d=JSON.parse(body);if(!validateEdition(d))return Response.json({error:'Invalid edition'},{status:400});
 await bindings.DB.prepare('INSERT INTO editions (date, updated_at, payload) VALUES (?, ?, ?) ON CONFLICT(date) DO UPDATE SET updated_at = excluded.updated_at, payload = excluded.payload WHERE excluded.updated_at > editions.updated_at').bind(d.date,d.updatedAt,JSON.stringify(d)).run();return Response.json({ok:true,date:d.date,issues:d.items.length});
 }catch{return Response.json({error:'Import failed'},{status:500})}
}
