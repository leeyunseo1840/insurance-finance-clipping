import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'보험·금융·경제 클리핑 | 고객에게 유익한 콘텐츠 소재',description:'보험·금리·물가·세금·연금·주거 등 설계사와 고객에게 도움이 되는 금융·경제 소식을 확인하세요.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ko"><body>{children}</body></html>}

